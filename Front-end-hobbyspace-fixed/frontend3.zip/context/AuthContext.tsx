import React, {
    createContext, useContext, useEffect, useState, useCallback,
} from 'react';
import { useRouter, useSegments } from 'expo-router';
import { authService } from '../services/authService';
import { setForceLogoutCallback } from '../services/api';
import type { User, LoginPayload, RegisterPayload } from '../types';

interface AuthContextData {
    user: User | null;
    isAuthenticated: boolean;
    isLoading: boolean;
    login:       (payload: LoginPayload)    => Promise<void>;
    register:    (payload: RegisterPayload) => Promise<void>;
    logout:      () => Promise<void>;
    refreshUser: () => Promise<void>;
}

const AuthContext = createContext<AuthContextData>({} as AuthContextData);

export function AuthProvider({ children }: { children: React.ReactNode }) {
    const [user, setUser]       = useState<User | null>(null);
    const [isLoading, setIsLoading] = useState(true);
    const router   = useRouter();
    const segments = useSegments();

    // ── Redireciona baseado em autenticação ─────────────────────────────
    useEffect(() => {
        if (isLoading) return;

        const inAuthGroup = segments[0] === 'auth';
        const inHome      = segments[0] === 'home' || segments[0] === 'community' ||
                            segments[0] === 'profile' || segments[0] === 'notifications' ||
                            segments[0] === 'settings' || segments[0] === 'chat';

        if (!user && inHome) {
            // Não autenticado em área protegida → vai para welcome
            router.replace('/');
        }
        // (se autenticado e em área pública, o index.tsx cuida do redirect)
    }, [user, isLoading, segments]);

    // ── Restaura sessão ─────────────────────────────────────────────────
    useEffect(() => {
        let isMounted = true;
        (async () => {
            try {
                const storedUser = await authService.getStoredUser();
                if (isMounted && storedUser) setUser(storedUser);
            } catch { if (isMounted) setUser(null); }
            finally  { if (isMounted) setIsLoading(false); }
        })();
        return () => { isMounted = false; };
    }, []);

    // ── Registra callback de force-logout para o api.ts ─────────────────
    useEffect(() => {
        setForceLogoutCallback(() => {
            setUser(null);
            // O useEffect de segments cuida do redirect
        });
    }, []);

    const login = useCallback(async (payload: LoginPayload) => {
        const response = await authService.login(payload);
        setUser(response.user);
    }, []);

    const register = useCallback(async (payload: RegisterPayload) => {
        const response = await authService.register(payload);
        setUser(response.user);
    }, []);

    const logout = useCallback(async () => {
        try {
            await authService.logout();
        } finally {
            setUser(null);
            router.replace('/');
        }
    }, [router]);

    const refreshUser = useCallback(async () => {
        try {
            const fresh = await authService.getProfile();
            setUser(fresh);
        } catch (err: any) {
            // Se 401 → force logout já é tratado pelo api.ts
            console.error('[refreshUser]', err?.message);
        }
    }, []);

    return (
        <AuthContext.Provider value={{
            user, isAuthenticated: !!user, isLoading,
            login, register, logout, refreshUser,
        }}>
            {children}
        </AuthContext.Provider>
    );
}

export function useAuth() {
    const ctx = useContext(AuthContext);
    if (!ctx) throw new Error('useAuth deve ser usado dentro de <AuthProvider>');
    return ctx;
}
